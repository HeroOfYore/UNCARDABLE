
SMODS.Atlas{
	key = "RANDOM_SELECT",
	path = "UNRANDOMABLE.png",
	atlas_table ="ANIMATION_ATLAS",
	frames = 9,
	fps = 10,
	px = 71,
	py = 95,
}


local base_ease_dollars = ease_dollars
function ease_dollars(mod, x)
    base_ease_dollars(mod, x)

    SMODS.calculate_context({uncardable_ease_dollars = mod})

end

G.FUNCS.total_reskins = function(e)
	G.uncard_prev_collec = "total_reskins"
    G.FUNCS.overlay_menu({
        definition = UNCARDABLE_create_UIBox_your_collection_content_sets(),
    })
end

G.FUNCS.planet_reskins = function(e)
	G.uncard_prev_collec = "planet_reskins"
	G.FUNCS.overlay_menu({
		definition = UNCARDABLE_create_planet_UIBox(),
	})
end

function UNCARDABLE_create_UIBox_your_collection_content_sets()
	local deck_tables = {}

	G.your_collection = {}
	for j = 1, 3 do
		G.your_collection[j] = CardArea(
			G.ROOM.T.x + 0.2 * G.ROOM.T.w / 2,
			G.ROOM.T.h,
			5 * G.CARD_W,
			0.95 * G.CARD_H,
			{card_limit = 4, type = "title", highlight_limit = 0, collection = true }
		)
		table.insert(deck_tables, {
			n = G.UIT.R,
			config = {align = "cm", padding = 0.07, no_fill = true},
			nodes = {
				{n = G.UIT.O, config = {object = G.your_collection[j] } },
			},
		})
	end
	
	local joker_pool = {}
	for k, v in pairs(G.P_CENTER_POOLS.Joker) do
		if not v.original_mod then
			table.insert(joker_pool, v)
			--print(v.key)
		end
		--print(v.original_mod.id)
	end
	local joker_options = {}
	for i = 1, math.ceil(#joker_pool / (5 * #G.your_collection)) do
		table.insert(
			joker_options, 
			"Page " 
			.. tostring(i) 
			.. "/" 
			.. tostring(math.ceil(#joker_pool / (5 * #G.your_collection)))
		)
	end

	local indexnum = 1
	for i = 1, #G.your_collection do
		for j = 1, 5 do
			local center = joker_pool[indexnum]
			--print(center.key, #G.your_collection, joker_pool[indexnum].key)
			local card = Card(G.your_collection[i].T.x + G.your_collection[i].T.w / 2, G.your_collection[i].T.y, G.CARD_W,G.CARD_H,nil, G.P_CENTERS[center.key])
			
			G.your_collection[i]:emplace(card)
			indexnum = indexnum + 1
		end
	end

	local t = create_UIBox_generic_options({
		back_func = G.ACTIVE_MOD_UI and "openModUI_" .. G.ACTIVE_MOD_UI.id or "your_collection",
		contents = {
			{ n = G.UIT.R, config = { align = "cm", r = 0.1, colour = G.C.BLACK, emboss = 0.05 }, nodes = deck_tables },
			{
				n = G.UIT.R,
				config = { align = "cm" },
				nodes = {
					create_option_cycle({
						options = joker_options,
						w = 4.5,
						cycle_shoulders = true,
						opt_callback = "uncardable_your_collection_content_set_page",
						current_option = 1,
						colour = G.C.RED,
						no_pips = true,
						focus_args = {snap_to = true, nav = "wide"},
					})
				}
			}
		}
	})
	return t
end

function UNCARDABLE_create_UIBox_your_collection_current_set()
	local deck_tables = {}
	G.your_collection = {}
	for j = 1, 3 do
		G.your_collection[j] = CardArea(
			G.ROOM.T.x + 0.2 * G.ROOM.T.w / 2,
			G.ROOM.T.h,
			5 * G.CARD_W,
			0.95 * G.CARD_H,
			{card_limit = 4, type = "title", highlight_limit = 0, collection = true }
		)
		table.insert(deck_tables, {
			n = G.UIT.R,
			config = {align = "cm", padding = 0.07, no_fill = true},
			nodes = {
				{n = G.UIT.O, config = {object = G.your_collection[j] } },
			},
		})
	end

	joker_pool = {}
	for j = 1, #G.P_CENTER_POOLS.Joker do
		--print(G.P_CENTER_POOLS.Joker[j].name)
	end

	local joker_options = {}
	for i = 1, math.ceil(#G.P_CENTER_POOLS.Joker / (5 * #G.your_collection)) do
		table.insert(
			joker_options,
			"Page"
				.. " "
				.. tostring(i)
				.. "/"
				.. tostring(math.ceil(#G.P_CENTER_POOLS.Joker / (5 * #G.your_collection)))
		)
	end

	INIT_COLLECTION_CARD_ALERTS()

	local t = create_UIBox_generic_options({
		contents = {
			{n = G.UIT.R, config = {align = "cm", r = 0.1, colour = G.C.BLACK, emboss = 0.05}, nodes = deck_tables}
		}
	})
	return t
end

G.FUNCS.uncardable_your_collection_content_set_page = function(args)
	if not args or not args.cycle_config then
		return
	end
	for j = 1, #G.your_collection do
		for i = #G.your_collection[j].cards, 1, -1 do
			local c = G.your_collection[j]:remove_card(G.your_collection[j].cards[i])
			c:remove()
			c = nil
		end
	end
	local joker_pool = {}
	for k, v in pairs(G.P_CENTER_POOLS.Joker) do
		if not v.original_mod then
			table.insert(joker_pool, v)
		end
	end

	local indexnum = 1
	for i = 1, #G.your_collection do
		for j = 1, 5 do
			local center = joker_pool[indexnum + (5 * #G.your_collection * (args.cycle_config.current_option - 1))]
			local card = Card(G.your_collection[i].T.x + G.your_collection[i].T.w / 2, G.your_collection[i].T.y, G.CARD_W,G.CARD_H,nil, G.P_CENTERS[center.key])
			
			G.your_collection[i]:emplace(card)
			indexnum = indexnum + 1
		end
	end
	INIT_COLLECTION_CARD_ALERTS()
end

function UNCARDABLE.generic_card(center, x, y)
	local card = Card(
		x or G.ROOM.T.x + 0.2 * G.ROOM.T.w / 2,
		y or G.ROOM.T.h,
		G.CARD_W,
		G.CARD_H,
		nil,
		G.P_CENTERS.c_base
	)

	return card
end


local card_click_ref = Card.click
function Card:click()
	card_click_ref(self)
	--print("clicked a card")
	if G.your_collection then
		for k, v in pairs(G.your_collection) do
			if
				self.area == v
				and G.ACTIVE_MOD_UI
				and G.ACTIVE_MOD_UI.id == "UNCARDABLE"
			then
				print("starting")
				if self.alternate_select then
					print("true")
					Card.uncardable_set_alternate(self, self.config.center, self.config.center.force_alternate)
				end
				UNCARDABLE.alternate_config_ui(self.config.center)
			end
		end
	end
	if G.planet_collection then
		for k, v in pairs(G.planet_collection) do
			if
				self.area == v
				and G.ACTIVE_MOD_UI
				and G.ACTIVE_MOD_UI.id == "UNCARDABLE"
			then
				if self.alternate_select then
					Card.uncardable_set_planalternate(self, self.config.center, self.config.center.force_alternate)
				end
				UNCARDABLE.alternate_config_planets(self.config.center)
			end
		end
	end
end

function UNCARDABLE.alternate_config_ui(center)
	--print(center.key)
	G.SETTINGS.paused = true
	G.your_collection = {}
	G.your_collection[1] = CardArea(
		G.ROOM.T.x + 0.2 * G.ROOM.T.w / 2,
		G.ROOM.T.h,
		5.3 * G.CARD_W,
		1.03 * G.CARD_H,
		{ card_limit = 5, type = "title", highlight_limit = 0, collection = true }
	)
	local deck_tables = {
		n = G.UIT.R,
		config = { align = "cm", padding = 0, no_fill = true },
		nodes = {
			{ n = G.UIT.O, config = { object = G.your_collection[1]}},
		},
	}

	local skins = {}
	local animated_skins = {}
	local startingvalue = 0
	local skinstartpoint = 0
	skins[#skins+1] = G.UNCARDABLE_jokers1[center.key]
	if G.UNCARDABLE_jokers1[center.key] == nil then
		skinstartpoint = skinstartpoint + 1
	end
	if G.UNCARDABLE_jokers2[center.key] ~= nil then
		skins[#skins+1] = G.UNCARDABLE_jokers2[center.key]
	end
	if G.UNCARDABLE_jokers3[center.key] ~= nil then
		skins[#skins+1] = G.UNCARDABLE_jokers3[center.key]
	end

	if G.UNCARDABLE_animated_jokers[center.key] ~= nil then
		animated_skins[#animated_skins+1] = G.UNCARDABLE_animated_jokers[center.key]
		startingvalue = startingvalue + 1
	end
	
	local randomcenter = UNCARDABLE.deep_copy(center)
	randomcenter.force_alternate = nil
	local randomcard = Card(G.ROOM.T.x + 0.2 * G.ROOM.T.w / 2, G.ROOM.T.y, G.CARD_W, G.CARD_H, nil, randomcenter)
	randomcard.children.center:remove()
	randomcard.children.center = SMODS.create_sprite(randomcard.T.x, randomcard.T.y, randomcard.T.w, randomcard.T.h, G.ANIMATION_ATLAS["uncardable_RANDOM_SELECT"], {x=0, y=0})
	randomcard.children.center:set_role({major = randomcard, role_type = 'Glued', draw_major = randomcard})
	randomcard.alternate_select = true
	local randomobj = randomcard.config.center or (randomcard.config.tag and G.P_TAGS[randomcard.config.tabs.key])
	randomobj.artist_credits = {"heroofyore"}
	G.your_collection[1]:emplace(randomcard)
	print("skinnum: " .. #skins)
	--print(skins[1].pos, skins[2])
	for i = 1, #animated_skins do
		print(animated_skins[i].row)
		local dummycenter = UNCARDABLE.deep_copy(center)
		dummycenter.force_alternate = animated_skins[i].anim
		local card = Card(G.ROOM.T.x + 0.2 * G.ROOM.T.w / 2, G.ROOM.T.y, G.CARD_W, G.CARD_H, nil, dummycenter)
		--print(G.ANIMATION_ATLAS["uncardable_" .. animated_skins[i].anim])
		card.children.center:remove()
		card.children.center = SMODS.create_sprite(card.T.x, card.T.y, card.T.w, card.T.h, G.ANIMATION_ATLAS["uncardable_" .. animated_skins[i].anim], {x = 0, y = animated_skins[i].row})
		card.children.center:set_role({major = card, role_type = 'Glued', draw_major = card})
		--card.children.center.atlas = G.ANIMATION_ATLAS["uncardable_".. animated_skins[i].anim]
		--card.children.center:set_sprite_pos({x = 0, y = animated_skins[i].row})
		card.alternate_select = true
		local obj = card.config.center or (card.config.tag and G.P_TAGS[card.config.tabs.key])
		obj.artist_credits = animated_skins[i].artist
		G.your_collection[1]:emplace(card)
	end
	for i = 1, #skins do
		print(skins[i].pos, "uncardable_agglomeration"..i, skins[i].artist[1])
		print(skins[i].pos, skins[i], skinstartpoint, "agglomeration"..i+skinstartpoint)
		local dummycenter = UNCARDABLE.deep_copy(center)
		dummycenter.force_alternate = "agglomeration" .. i + skinstartpoint
		print(dummycenter.key)
		local card = Card(G.ROOM.T.x + 0.2 * G.ROOM.T.w / 2, G.ROOM.T.y, G.CARD_W, G.CARD_H, nil, dummycenter)
		
		card.children.center:remove()
		card.children.center = SMODS.create_sprite(G.ROOM.T.x + 0.2 * G.ROOM.T.w, G.ROOM.T.y, G.CARD_W, G.CARD_H, G.ASSET_ATLAS["uncardable_agglomeration"..i+skinstartpoint], {x = 0 + skins[i].pos, y = 0})
		card.children.center:set_role({major = card, role_type = 'Glued', draw_major = card})
		--card.children.center.atlas = G.ASSET_ATLAS["uncardable_agglomeration" .. i+skinstartpoint]
		--card.children.center:set_sprite_pos({x = 0 + skins[i].pos, y = 0})
		card.alternate_select = true
		local obj = card.config.center or (card.config.tag and G.P_TAGS[card.config.tag.key])
		obj.artist_credits = skins[i].artist
		G.your_collection[1]:emplace(card)

	end


	INIT_COLLECTION_CARD_ALERTS()
	local args = {
		back_func = G.uncard_prev_collec,
		contents = {
			{
				n = G.UIT.R,
				config = {align = "cm", minw = 2.0, padding = 0.1, r = 0.1, colour = G.C.BLACK, emboss = 0.05},
				nodes = { deck_tables},
			},
		},	
	}
	local configbox = create_UIBox_generic_options(args)
	G.FUNCS.overlay_menu({
		definition = configbox,
	})
end

function UNCARDABLE_create_planet_UIBox()
	local planet_tables = {}
	G.planet_collection = {}
	for j = 1, 3 do
		G.planet_collection[j] = CardArea(
			G.ROOM.T.x + 0.2 * G.ROOM.T.w / 2,
			G.ROOM.T.h, 
			5 * G.CARD_W,
			0.95 * G.CARD_H,
			{card_limit = 4, type = "title", highlight_limit = 0, collection = true}
		)
		table.insert(planet_tables, {
			n = G.UIT.R,
			config = {align = "cm", padding = 0.07, no_fill = true},
			nodes = {
				{n = G.UIT.O, config = {object = G.planet_collection[j]}},
			},
		})
	end
	local planet_pool = {}
	for k, v in pairs(G.P_CENTER_POOLS.Planet) do
			--print(v.key)
			table.insert(planet_pool, v)
	end
	--print(#G.planet_collection)
	local indexnum = 1
	for i = 1, #G.planet_collection do
		for j = 1, 4 do
			if indexnum < #planet_pool then
				local center = planet_pool[indexnum]
				local card = Card(G.planet_collection[i].T.x + G.planet_collection[i].T.w / 2, G.planet_collection[i].T.y, G.CARD_W, G.CARD_H, nil, G.P_CENTERS[center.key])
				G.planet_collection[i]:emplace(card)
				indexnum = indexnum + 1
			end
		end
	end

	local t = create_UIBox_generic_options({
		back_func = G.ACTIVE_MOD_UI and "openModUI_" .. G.ACTIVE_MOD_UI.id or "planet_collection",
		contents = {
			{ n = G.UIT.R, config = { align = "cm", r = 0.1, colour = G.C.BLACK, emboss = 0.05}, nodes = planet_tables},
		}
	})
	return t
end

function UNCARDABLE.alternate_config_planets(center)
	G.SETTINGS.paused = true
	G.planet_collection = {}
	G.planet_collection[1] = CardArea(
		G.ROOM.T.x + 0.2 * G.ROOM.T.w / 2,
		G.ROOM.T.h,
		5.3 * G.CARD_W,
		1.03 * G.CARD_H,
		{ card_limit = 4, type = "title", highlight_limit = 0, collection = true,}
	)
	local planet_tables = {
		n = G.UIT.R,
		config = { align = "cm", padding = 0, no_fill = true},
		nodes = {
			{ n = G.UIT.O, config = {object = G.planet_collection[1]}},
		},
	}
	print(center.key)
	--print(center)
	local variants = G.UNCARDABLE_planets[center.key].variants
	local planetcard = G.UNCARDABLE_planets[center.key]
	print(variants)
	--print(planetcard)
	local randomcenter = UNCARDABLE.deep_copy(center)
	randomcenter.force_alternate = nil
	local randomcard = Card(G.ROOM.T.x + 0.2 * G.ROOM.T.w / 2, G.ROOM.T.y, G.CARD_W, G.CARD_H, nil, randomcenter)
	randomcard.children.center:remove()
	randomcard.children.center = SMODS.create_sprite(randomcard.T.x, randomcard.T.y, randomcard.T.w, randomcard.T.h, G.ANIMATION_ATLAS["uncardable_RANDOM_SELECT"], {x=0, y=0})
	randomcard.children.center:set_role({major = randomcard, role_type = 'Glued', draw_major = randomcard})
	randomcard.alternate_select = true
	G.planet_collection[1]:emplace(randomcard)
	for i = 1, variants do
		local dummycenter = UNCARDABLE.deep_copy(center)
		dummycenter.force_alternate = i
		local card = Card(G.ROOM.T.x + 0.2 * G.ROOM.T.w / 2, G.ROOM.T.y, G.CARD_W, G.CARD_H, nil, dummycenter)
		card.children.center:remove()
		card.children.center = SMODS.create_sprite(card.T.x, card.T.y, card.T.w, card.T.h, G.ANIMATION_ATLAS["uncardable_" .. planetcard.anim .. "_anim"], {x = 0, y = i - 1})
		card.children.center:set_role({major = card, role_type = 'Glued', draw_major = card})
		card.alternate_select = true
		local obj = card.config.center
		obj.artist_credits = planetcard.artist
		G.planet_collection[1]:emplace(card)
	end
	
	--INIT_COLLECTION_CARD_ALERTS()
	local args = {
		back_func = G.uncard_prev_collec,
		contents = {
			{
				n = G.UIT.R,
				config = {align = "cm", minw = 2.0, padding = 0.1, r = 0.1, colour = G.C.BLACK, emboss = 0.05},
				nodes = {planet_tables},
			},
		},
	}
	local configbox = create_UIBox_generic_options(args)
	G.FUNCS.overlay_menu({
		definition = configbox,
	})
end

--[[function UNCARDABLE.alternates(card, center)
	if not center then
		if not card then
			return G.PROFILES[G.SETTINGS.profile].uncardable_alternates
		end
	center = card.config and card.config.center or card.effect and card.effect.center or card
	end
	if card.force_alternate then
		return card.force_alternate
	end
	if center.force_alternate then
		return center.force_alternate
	end
	
end]]

function Card:uncardable_set_planalternate(center, alternate)
	print("alternate: ", alternate, " center: ", center.key)
	if G.PROFILES[G.SETTINGS.profile].uncardable_planalternates == nil then
		G.PROFILES[G.SETTINGS.profile].uncardable_planalternates = {}
	end
	if alternate == nil
	then
		G.PROFILES[G.SETTINGS.profile].uncardable_planalternates[center.key] = nil
		UNCARDABLE.UNCARD_REINIT_PLANETS()
		return
	end
	if G.PROFILES[G.SETTINGS.profile].uncardable_planalternates[center.key] == alternate-1
	then
		return
	end
	G.PROFILES[G.SETTINGS.profile].uncardable_planalternates[center.key] = alternate-1
	G:save_progress()
	UNCARDABLE.UNCARD_REINIT_PLANETS()
end

function Card:uncardable_set_alternate(center, alternate)
	--print("alternate: ", alternate, ", self: ", self)
	if G.PROFILES[G.SETTINGS.profile].uncardable_alternates == nil then
		G.PROFILES[G.SETTINGS.profile].uncardable_alternates = {}
	end
	if G.PROFILES[G.SETTINGS.profile].uncardable_alternates[center.key] == alternate
	then
		return
	end
	G.PROFILES[G.SETTINGS.profile].uncardable_alternates[center.key] = alternate
	G:save_progress()
	UNCARDABLE.UNCARD_REINIT_SPRITES()
end

function UNCARDABLE.deep_copy(curr, seen)
	if type(curr) ~= "table" then
		return curr
	end
	if seen and seen[curr] then
		return seen[curr]
	end
	local s = seen or {}
	local res = setmetatable({}, getmetatable(curr))
	s[curr] = res
	for k, v in pairs(curr) do
		res[UNCARDABLE.deep_copy(k, s)] = UNCARDABLE.deep_copy(v, s)
	end
	return res
end

function UNCARDABLE.create_overlay(content)
	G.OVERLAY_MENU = UIBox{
		definition = content,
		config = {offset = {x = 0, y = 0}, align = 'cm', parent = G.OVERLAY}
	}
end
function UNCARDABLE.TN_note()
	local text_display = {
		{n = G.UIT.R, config = {align = "cm", padding = 0.0, color = {0.1, 0.1, 0.1, 1}},
	nodes = {{n = G.UIT.T, config = {text = "TN: It should be all caps or no caps", scale = 0.6, colour = G.ARGS.LOC_COLOURS["MUSTARD"]}}}}
	}
end

local set_spritesref = Card.set_sprites
function Card:set_sprites(center, front)
	set_spritesref(self, center, front)
	if center then 
		--print(center.atlas)
	end
end
