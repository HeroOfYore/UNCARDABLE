
    G.UNCARDABLE_jokers1 = {
        j_8_ball = {pos = 0, artist = {'heroofyore'}},
        j_mr_bones = {pos = 1, artist = {'heroofyore'}},
        j_sixth_sense = {pos = 2, artist = {'heroofyore'}},
        j_stencil = {pos = 3, artist = {'heroofyore'}},
        --j_wee = {pos = 4, artist = {'guac', 'heroofyore'}, {name = "j_wee"}},
        j_photograph = {pos = 5, artist = {'heroofyore'}},
        j_diet_cola = {pos = 6, artist = {'heroofyore'}},
        j_ice_cream = {pos = 7, artist = {'heroofyore'}},
        j_gros_michel = {pos = 8, artist = {'heroofyore'}},
        j_castle = {pos = 9, artist = {'heroofyore'}},
        j_cavendish = {pos = 10, artist = {'heroofyore'}},
        j_selzer = {pos = 11, artist = {'heroofyore'}},
        j_hanging_chad = {pos = 12, artist = {'heroofyore'}},
        j_scary_face = {pos = 13, artist = {'heroofyore'}},
        j_acrobat = {pos = 14, artist = {'heroofyore'}},
        j_abstract = {pos = 15, artist = {'heroofyore'}},
        j_matador = {pos = 16, artist = {'ermywurm'}},
        j_ride_the_bus = {pos = 17, artist = {'heroofyore'}},
        j_blueprint = {pos = 18, artist = {'heroofyore'}},
        j_business = {pos = 19, artist = {'ermywurm'}},
        j_devious = {pos = 20, artist = {'ermywurm'}},
        j_luchador = {pos = 21, artist = {'heroofyore'}},
        j_swashbuckler = {pos = 22, artist = {'heroofyore'}},
        j_mail = {pos = 23, artist = {'ploutre'}},
        j_hologram = {pos = 24, artist= {'stanza'}},
        j_space = {pos = 25, artist = {'heroofyore'}},
        j_satellite = {pos = 26, artist = {'heroofyore'}},
        j_delayed_grat = {pos = 27, artist = {'ploutre'}},
        j_faceless = {pos = 28, artist = {'objitude'}},
        j_bootstraps = {pos = 29, artist = {'ploutre'}},
        j_vagabond = {pos = 30, artist = {'objitude'}},
        j_smiley = {pos = 31, artist = {'heroofyore'}},
        j_trousers = {pos = 32, artist = {'ploutre'}},
        j_cloud_9 = {pos = 33, artist = {'ploutre'}},
        j_joker = {pos = 34, artist = {'guac'}},
        j_ring_master = {pos = 35, artist = {'ploutre'}},
        --j_mime = {pos = 36, artist = {'heroofyore'}},
        --j_even_steven = {pos = 37, artist = {'murdock'}},
        j_sock_and_buskin = {pos = 38, artist = {'8z'}},
        j_steel_joker = {pos = 39, artist={'stanza'}},
        j_to_the_moon = {pos = 40, artist={'birb'}},
        j_sly = {pos= 41, artist={'8z'}},
        j_greedy_joker = {pos = 42, artist = {'epicelle'}},
        j_ticket = {pos = 43, artist={'heroofyore'}},
        j_bull = {pos = 44, artist = {'heroofyore'}},
        j_troubadour = {pos = 45, artist = {'epicelle'}},
        j_dna = {pos = 46, artist = {'murdock'}},
        j_cartomancer = {pos = 48, artist = {'objitude'}},
        j_glass = {pos = 49, artist = {'heroofyore'}},
        j_stuntman = {pos = 50, artist = {'fieldofgrass'}},
        j_four_fingers = {pos = 51, artist = {'ploutre'}},
        j_walkie_talkie = {pos = 52, artist ={'suvi'}},
        j_trading = {pos = 53, artist = {'heroofyore'}},
        j_flash = {pos = 54, artist = {'heroofyore'}},
        j_juggler = {pos = 55, artist = {'ploutre'}},
        j_seeing_double = {pos = 56, artist = {'ploutre'}},
        j_drunkard = {pos = 57, artist = {'ploutre'}},
        j_certificate = {pos = 58, artist = {'yuki'}},
        --j_credit_card = {pos = 59, artist = {'ploutre'}},
        j_square = {pos = 60, artist = {'ploutre'}},
        j_shortcut = {pos = 61, artist = {'heroofyore'}},
        j_blackboard = {pos = 62, artist = {'grimp'}},
        j_pareidolia = {pos = 63, artist = {'stanza'}},
        j_ancient = {pos = 64, artist = {'murdock'}},
        j_midas_mask = {pos = 65, artist = {'heroofyore'}},
        j_banner = {pos = 66, artist = {'heroofyore'}},
        j_oops = {pos = 67, artist = {'murdock'}},
        j_hiker = {pos = 68, artist = {'heroofyore'}},
        j_half = {pos = 69, artist = {'heroofyore'}},
        j_marble = {pos = 70, artist = {'heroofyore'}},
        j_clever = {pos = 71, artist = {'heroofyore'}},

    }

    G.UNCARDABLE_jokers2 = {
        j_drunkard = {pos = 0, artist = {'yuki'}},
        j_jolly = {pos = 1, artist = {'grimp'}},
        j_mad = {pos = 2, artist = {'feesh'}},
        j_hack = {pos = 3, artist = {'stanza'}},
        j_certificate = {pos = 4, artist = {'heroofyore'}},
    }

    G.UNCARDABLE_jokers3 = {
        j_jolly = {pos = 0, artist = {'grimp'}},

    }


    SMODS.Atlas {
        key = "agglomeration1",
        path = "AGGLOMERATION1.png",
        px = 71, 
        py = 95
    }
    SMODS.Atlas {
        key = "agglomeration2",
        path = "AGGLOMERATION2.png",
        px = 71,
        py = 95,
    }
    SMODS.Atlas {
        key = "agglomeration3",
        path = "AGGLOMERATION3.png",
        px = 71,
        py = 95,
    }

    if G.PROFILES[G.SETTINGS.profile].uncardable_alternates == nil then
	    G.PROFILES[G.SETTINGS.profile].uncardable_alternates = {}
    end

    if not UNCARDABLE.config.disabled then
        
        for jkr, data in pairs(G.UNCARDABLE_jokers1) do
            --print(G.PROFILES[G.SETTINGS.profile].uncardable_alternates[jkr])
            --[[if G.PROFILES[G.SETTINGS.profile].uncardable_alternates[jkr] ~= nil then
                local otherdata = G.UNCARDABLE_jokers2[jkr]
                print(otherdata, "winning")
                SMODS["Joker"]:take_ownership(jkr, {atlas = G.PROFILES[G.SETTINGS.profile].uncardable_alternates[jkr],
                pos = {x = 0 + otherdata.pos, y = 0},
                artist_credits = otherdata.artist,
                soul_pos = {x = 0 + data.pos, y = 1},
                }, true)
            else]]--
                local totalskinnum = 0
                
                SMODS["Joker"]:take_ownership(jkr, {atlas = "agglomeration1",
                pos = {x = 0 + data.pos, y = 0},
                artist_credits = data.artist,
                soul_pos = {x = 0 + data.pos, y = 1},
                }, true)
            --end
        end
    end

    --[[ This section is for jokers with special properties e.g. popcorn and wee joker]]
    SMODS.Atlas {
        key = "multistage",
        path = "MULTISTAGE.png",
        px = 71,
        py = 95
    }
    SMODS.Atlas {
        key = "unrecordable",
        path = "UNRECORDABLE.png",
        px = 71,
        py = 95
    }
    SMODS.Atlas{
        key = "uncashable",
        path = "UNCASHABLE.png",
        px = 71,
        py = 95,
    }
    SMODS.Atlas{
        key = "unmaidable",
        path = "UNMAIDABLE.png",
        px = 71,
        py = 95,
    }
    SMODS.Atlas{
        key = "unquaverlingable",
        path = "UNQUAVERLINGABLE.png",
        px =  71,
        py = 95,
    }





    if not UNCARDABLE.config.disabled then
        SMODS.Joker:take_ownership("j_popcorn", {
            atlas = "multistage",
            name = "uncardable_popcorn",
            pos = {x = 0, y = 0},
            artist_credits = {"8z"},
            config = {extra = 0, extran = {mult_loss = 4, mult = 20, cardpos = 0}},
            loc_vars = function(self, info_queue, card)
                return { vars = { card.ability.extran.mult, card.ability.extran.mult_loss } }
            end,
            calculate = function(self, card, context)
                if context.end_of_round and context.game_over == false and context.main_eval and not context.blueprint then
                    if card.ability.extran.mult - card.ability.extran.mult_loss <= 0 then
                        SMODS.destroy_cards(card, nil, nil, true)
                        return {
                            message = localize('msg_eaten'),
                            colour = G.C.RED
                        }
                    else
                        card.ability.extran.mult = card.ability.extran.mult - card.ability.extran.mult_loss 
                        card.ability.extran.cardpos = card.ability.extran.cardpos + 1
                        return
                        {
                            message = localize{type = 'variable', key = 'a_mult_minus', vars = {card.ability.extran.mult_loss}},
                            colour = G.C.MULT, 
                            card.children.center:set_sprite_pos({x = card.ability.extran.cardpos, y = 0})
                        }
                    end
                end
                if context.joker_main then
                    return {
                        mult = card.ability.extran.mult
                    }
                end
                return nil, true
            end
        }, true)
        SMODS.Joker:take_ownership("j_turtle_bean", {
            atlas = "unquaverlingable",
            pos = {x = 0, y = 0},
            artist_credits = {"heroofyore"},
            config = {extra = {h_size = 5, h_mod = 1, cardpos = 0}},
            loc_vars = function(self, info_queue, card)
                return { vars = {card.ability.extra.h_size, card.ability.extra.h_mod}}
            end,
            calculate = function(self, card, context)
                if context.end_of_round and context.game_over == false and context.main_eval and not context.blueprint then
                    if card.ability.extra.h_size - card.ability.extra.h_mod <= 0 then
                        SMODS.destroy_cards(card, nil, nil, true)
                        return {
                            message = localize('msg_fed'),
                            colour = G.C.RED
                        }
                    else
                        card.ability.extra.h_size = card.ability.extra.h_size - card.ability.extra.h_mod
                        G.hand:change_size(-card.ability.extra.h_mod)
                        card.ability.extra.cardpos = card.ability.extra.cardpos + 1

                        return {
                            message = localize {type = 'variable', key = 'a_handsize_minus', vars = {card.ability.extra.h_mod}},
                            colour = G.C.FILTER,
                            card.children.center:set_sprite_pos({x = card.ability.extra.cardpos, y = 0})
                        }
                    end
                end
            end,
            add_to_deck = function(self, card, from_debuff)
                G.hand:change_size(card.ability.extra.h_size)
            end,
            remove_from_deck = function(self, card, from_debuff)
                G.hand:change_size(-card.ability.extra.h_size)
            end

        }, true)
        SMODS.Joker:take_ownership("j_loyalty_card", {
            atlas = "unrecordable",
            pos = {x = 0, y = 0},
            artist_credits = {"heroofyore"},
            config = { extra = {Xmult = 4, every = 5, loyalty_remaining = 5} },
            loc_vars = function(self, info_queue, card)
                return {
                    vars = {
                        card.ability.extra.Xmult,
                        card.ability.extra.every + 1,
                        localize {type = 'variable', key = (card.ability.extra.loyalty_remaining == 0 and 'loyalty_active' or 'loyalty_inactive'), vars = {card.ability.extra.loyalty_remaining} }        
                    }
                }
            end,
            calculate = function(self, card, context)
                if context.joker_main then 
                    card.ability.extra.loyalty_remaining = (card.ability.extra.every - 1 - (G.GAME.hands_played - card.ability.hands_played_at_create)) %
                    (card.ability.extra.every + 1)
                    card.children.center:set_sprite_pos({x = 5 - card.ability.extra.loyalty_remaining, y = 0})
                    if not context.blueprint then
                        if card.ability.extra.loyalty_remaining == 0 then
                            local eval = function(card) return card.ability.extra.loyalty_remaining == 0 and not G.RESET_JIGGLES end
                            juice_card_until(card, eval, true)
                        end
                    end
                    if card.ability.extra.loyalty_remaining == card.ability.extra.every then
                        return {
                            xmult = card.ability.extra.Xmult
                        }
                    end
                end
            end

        }, true)

        SMODS.Joker:take_ownership("j_credit_card",  {
            atlas = "uncashable",
            pos = {x = 0, y = 0},
            artist_credits = {"ploutre"},
            config = { extra = 0, extran = { bankrupt_at = 20, spritenum = 0}},
            loc_vars = function(self, info_queue, card)
                return { vars = { card.ability.extran.bankrupt_at } }
            end,
            add_to_deck = function(self, card, from_debuff)
                G.GAME.bankrupt_at = G.GAME.bankrupt_at - card.ability.extran.bankrupt_at
            end,
            remove_from_deck = function(self, card, from_debuff)
                G.GAME.bankrupt_at = G.GAME.bankrupt_at + card.ability.extran.bankrupt_at
            end,

            calculate = function(self, card, context)
                if context.ease_dollars then
                    if G.GAME.dollars >= 0 then
                        card.ability.extran.spritenum = 0
                        return {
                            card.children.center:set_sprite_pos({x = 0, y = 0})
                        }
                    end
                    else if G.GAME.dollars < 0 then
                        card.ability.extran.spritenum = G.GAME.dollars * -1
                        return {
                            card.children.center:set_sprite_pos({x = card.ability.extran.spritenum, y = 0})
                        }
                    end
                end
            end
        }, true)

        SMODS.Joker:take_ownership("j_hologram", {
            soul_pos = {x = 24, y = 1, draw = function(card, size_mod, rotate_mod) 
                local rotate_mod = 0.1 * math.sin(1.219 * G.TIMERS.REAL) + 0.07 * math.sin((G.TIMERS.REAL) * math.pi * 5) * (1 - (G.TIMERS.REAL - math.floor(G.TIMERS.REAL))) ^ 2
                local size_mod = 1.25
            end}
        }, true)

        SMODS.Joker:take_ownership("j_crafty", {
            atlas = "unmaidable",
            pos = {x = 0, y = 0},
            artist_credits = {"ploutre"},
            set_sprites = function(self, card, front)
                local randomposweighted = math.random(0, 110)
                local pos
                if randomposweighted < 30 then
                    pos = 0
                end
                if randomposweighted < 60 and randomposweighted >= 30 then
                    pos = 1
                end
                if randomposweighted < 90 and randomposweighted >= 60 then
                    pos = 2
                end
                if randomposweighted < 100 and randomposweighted >= 90 then
                    pos = 3
                end
                if randomposweighted <= 110 and randomposweighted >= 100 then
                    pos = 4
                end
                card.children.center:set_sprite_pos({x = pos, y = 0})
            end
        }, true)

        SMODS.Joker:take_ownership("j_golden", {
            config = {extra = {dollars = 4}},
            loc_vars = function(self, info_queue, card)
                return {vars = {card.ability.extra.dollars}}
            end,
            calculate = function(self, card, context)
                if context.card_added then
                    if context.card == card then
                        SMODS.calculate_effect({message = 'TN: It should be all caps or no caps', duration = 20}, card)
                    end
                end
            end,
            calc_dollar_bonus = function(self, card)
                return card.ability.extra.dollars
            end,
            add_to_deck = function(self, card, from_debuff)
                SMODS.calculate_effect({message = 'TN: It should be all caps or no caps', duration = 20}, card)
            end
        }, true)
    end

  

    ---SECTION FOR MULTICHOICE JOKERS
    SMODS.Atlas
    {
        key = "multichoice",
        path = "MULTICHOICE.png",
        px = 71,
        py = 95,
    }
    SMODS.Atlas
    {
        key = "unobeliskable",
        path = "UNOBELISKABLE.png",
        px = 71,
        py = 95,
    }


    SMODS.Joker:take_ownership("j_hallucination", {
        atlas = "multichoice",
        pos = {x = 0, y = 0},
        artist_credits = {"heroofyore", "guac"},
        set_sprites = function(self, card, front)
            local randompos = math.random(0, 4)
            card.children.center:set_sprite_pos({x = randompos, y = 0})
        end
    }, true)

    SMODS.Joker:take_ownership("j_obelisk", {
        atlas = "unobeliskable",
        pos = {x = 0, y = 0},
        artist_credits = {"birb", "heroofyore"},
        set_sprites = function(self, card, front)
            local randompos = math.random(0, 2)
            card.children.center:set_sprite_pos({x = randompos, y = 0})
            if randompos ~= 0 then
                artist_credits = {"heroofyore"}
            else
                artist_credits = {"birb"}
            end
        end,
    }, true)


 
    --end of section


    G.UNCARDABLE_animated_jokers = {
        j_lucky_cat = {row = 0, artist = {'heroofyore'}, anim = "j_lucky_cat_anim"},
        j_gift = {row = 1, artist = {'heroofyore'}, anim = "j_gift_anim"},
        j_odd_todd = {row = 2, artist = {'heroofyore'}, anim = "j_odd_todd_anim"},
        j_brainstorm = {row = 3, artist = {'heroofyore'}, anim = "j_brainstorm_anim"},
        j_campfire = {row = 4, artist = {'heroofyore'}, anim = "j_campfire_anim"},

        j_smeared = {row = 0, artist = {'heroofyore'}, anim = "j_smeared_anim"},
        j_ramen = {row = 1, artist = {'heroofyore'}, anim = "j_ramen_anim"},
        j_flower_pot = {row = 2, artist = {'heroofyore'}, anim = "j_flower_pot_anim"},
        j_madness = {row = 3, artist = {'heroofyore'}, anim = "j_madness_anim"},
        j_zany = {row = 4, artist = {'$7bramble'}, anim = "j_zany_anim"},
        j_todo_list = {row = 0, artist = {'heroofyore'}, anim = "j_todo_list_anim"},

        j_wee = {row = 0, artist = {'guac', 'heroofyore'}, {name = "j_wee_anim"}},

        j_egg = {row = 0, artist = {'heroofyore'}, anim = "j_egg_anim"},
        j_burnt = {row = 1, artist = {'heroofyore'}, anim = "j_burnt_anim"},
        j_invisible = {row = 2, artist = {'heroofyore'}, anim = "j_invisible_anim"},

        j_bloodstone = {row = 0, artist = {'heroofyore'}, anim = "j_bloodstone_anim"},
        j_jolly = {row = 1, artist = {'$7bramble'}, anim = "j_jolly_anim"},

        j_constellation = {row = 0, artist = {'heroofyore'}, anim = "j_constellation_anim"},
        j_shoot_the_moon = {row = 1, artist = {'heroofyore'}, anim = "j_shoot_the_moon_anim"},

        j_superposition = {row = 0, artist = {'ermywurm'}, anim = "j_superposition_anim"},
        j_astronomer = {row = 1, artist = {'heroofyore'}, anim = "j_astronomer_anim"},
        j_baron = {row = 2, artist = {'heroofyore'}, anim = "j_baron_anim"},
        j_dusk = {row = 3, artist = {'heroofyore'}, anim = "j_dusk_anim"},

        j_misprint = {row = 0, artist = {'heroofyore'}, anim = "j_misprint_anim"},

        j_fibonacci = {row = 0, artist = {'heroofyore'}, anim = "j_fibonacci_anim"},

        j_vampire = {row = 0, artist = {'ermywurm'}, anim = "j_vampire_anim"},

        j_supernova = {row = 0, artist = {'heroofyore'}, anim = "j_supernova_anim"},

        j_throwback = {row = 0, artist = {'heroofyore'}, anim = "j_throwback_anim"},
        j_seance = {row = 1, artist = {'heroofyore'}, anim = "j_seance_anim"},

        j_hit_the_road = {row = 0, artist = {'heroofyore'}, anim = "j_hit_the_road_anim"},
        j_stone = {row = 0, artist = {'ploutre'}, anim = "j_stone_anim"},

        j_reserved_parking = {row = 0, artist= {'heroofyore'}, anim = "j_reserved_parking_anim"},

        j_droll = {row = 0, artist = {'$7bramble', 'heroofyore'}, anim = "j_droll_anim"},
        j_onyx_agate = {row = 0, artist = {'heroofyore'}, anim = "j_onyx_agate_anim"},

        j_rocket = {row = 0, artist = {'heroofyore'}, anim = "j_rocket_anim"},

        j_splash = {row = 0, artist = {'heroofyore'}, anim = "j_splash_anim"},
        
        j_drivers_license = {row = 0, artist = {'heroofyore'}, anim = "j_drivers_license_anim"},
    
        j_duo = {row = 0, artist = {'heroofyore'}, anim = "j_duo_anim"},
        j_trio = {row = 0, artist = {'heroofyore'}, anim = "j_trio_anim"},
        j_family = {row = 0, artist = {'heroofyore'}, anim = "j_family_anim"},
        j_order = {row = 0, artist = {'heroofyore'}, anim = "j_order_anim"},
        j_tribe = {row = 0, artist = {'heroofyore'}, anim = "j_tribe_anim"},

        j_raised_fist = {row = 0, artist = {'heroofyore'}, anim ="j_raised_fist_anim"},

        j_mystic_summit = {row = 0, artist = {'heroofyore'}, anim = "j_mystic_summit_anim"},
        j_erosion = {row = 0, artist = {'heroofyore'}, anim = "j_erosion_anim"},
        j_arrowhead = {row = 0, artist = {'heroofyore'}, anim ="j_arrowhead_anim"},

        j_red_card = {row = 0, artist = {'heroofyore'}, anim = "j_red_card_anim"},
        j_burglar = {row = 0, artist = {'heroofyore'}, anim = "j_burglar_anim"},
        j_wrathful_joker = {row = 0, artist = {'heroofyore'}, anim = "j_wrathful_joker_anim"},
        j_card_sharp = {row = 0, artist = {'heroofyore'}, anim = "j_card_sharp_anim"},
        j_even_steven = {row = 0, artist = {'murdock'}, anim = "j_even_steven_anim"},
        j_chaos = {row = 0, artist = {'heroofyore'}, anim = "j_chaos_anim"},
        j_gluttenous_joker = {row = 0, artist = {'heroofyore'}, anim = "j_gluttenous_joker_anim"},
        j_wily = {row = 0, artist = {'heroofyore'}, anim = "j_wily_anim"},
        j_mime = {row = 0, artist = {'heroofyore'}, anim = "j_mime_anim"},
        j_mad = {row = 0, artist = {'murdock'}, anim = "j_mad_anim"},
        j_hack = {row = 0, artist = {'heroofyore'}, anim = "j_hack_anim"},
        j_golden = {row = 0, artist = {'heroofyore'}, anim = "j_golden_anim"},
        j_baseball = {row = 0, artist = {'heroofyore'}, anim = "j_baseball_anim"},

        j_runner = {row = 0, artist = {'heroofyore'}, anim = "j_runner_anim"},

        j_scholar = {row = 0, artist = {'ploutre'}, anim = "j_scholar_anim"},

        j_idol = {row = 0, artist = {'heroofyore'}, anim = "j_idol_anim"},

        j_crazy = {row = 0, artist = {'heroofyore'}, anim = "j_crazy_anim"},
        j_riff_raff = {row = 0, artist = {'heroofyore'}, anim = "j_riff_raff_anim"},
        j_fortune_teller = {row = 0, artist = {'heroofyore'}, anim = "j_fortune_teller_anim"},
        j_rough_gem = {row = 0, artist = {'heroofyore'}, anim = "j_rough_gem_anim"},
        j_blue_joker = {row = 0, artist = {'heroofyore'}, anim = "j_blue_joker_anim"},
        j_lusty_joker = {row = 0, artist = {'heroofyore'}, anim = "j_lusty_joker_anim"},
    }
    animated_with_soul = {
        j_perkeo = {row = 0, artist = {'guac'}},
    }

    G.UNCARDABLE_reduced_animation = {
        j_raised_fist = {row = 0, artist = {'heroofyore'}, anim = "j_raised_fist_reduced_anim"},
        j_lusty_joker = {row = 0, artist = {'heroofyore'}, anim = "j_lusty_joker_reduced_anim"},
        j_mime = {row = 0, artist = {'heroofyore'}, anim = "j_mime_reduced_anim"},
        j_burglar = {row = 0, artist = {'heroofyore'}, anim = "j_burglar_reduced_anim"},
        j_onyx_agate = {row = 0, artist = {'heroofyore'}, anim = "j_onyx_agate_reduced_anim"},
        j_tribe = {row = 0, artist = {'heroofyore'}, anim = "j_tribe_reduced_anim"},
    }
    --[[ animated_sub_5 = {
        j_lucky_cat = {row = 0, artist = {'heroofyore'}},
        j_gift = {row = 1, artist = {'heroofyore'}},
        j_odd_todd = {row = 2, artist = {'heroofyore'}},
        j_brainstorm = {row = 3, artist = {'heroofyore'}},
    }

    animated_sub_10 = {
        j_smeared = {row = 0, artist = {'heroofyore'}},
        j_ramen = {row = 1, artist = {'heroofyore'}},
        j_flower_pot = {row = 2, artist = {'heroofyore'}},
        j_madness = {row = 3, artist = {'heroofyore'}},
        j_zany = {row = 4, artist = {'bramble'}},

    }

    animated_sub_15 = {
        j_egg = {row = 0, artist = {'heroofyore'}},
        j_burnt = {row = 1, artist = {'heroofyore'}},
        j_invisible = {row = 2, artist = {'heroofyore'}},
    }
    animated_sub_25 = {
        j_bloodstone = {row = 0, artist = {'heroofyore'}},
        j_jolly = {row = 1, artist = {'bramble'}},
    }
    animated_sub_30 = {
        j_constellation = {row = 0, artist = {'heroofyore'}},
        j_shoot_the_moon = {row = 1, artist = {'heroofyore'}},
    }

    animated_sub_40 = {
        j_baseball = {row = 0, artist = {'heroofyore'}},
        j_superposition = {row = 1, artist = {'ermywurm'}},
        j_astronomer = {row = 2, artist = {'heroofyore'}},
        j_baron = {row = 3, artist = {'heroofyore'}},
        j_dusk = {row = 4, artist = {'heroofyore'}},
    }

    animated_sub_50 = {
        j_misprint = {row = 0, artist = {'heroofyore'}},
    }
    
    animated_sub_65 = {
        j_fibonacci = {row = 0, artist = {'heroofyore'}},
    }
    animated_sub_80 = {
        j_vampire = {row = 0, artist = {'ermywurm'}},
    }

    animated_sub_90 = {
        j_supernova = {row = 28, artist = {'heroofyore'}},
    }

    animated_plus_hundred = {
        j_throwback = {row = 0, artist = {'heroofyore'}},
        j_seance = {row = 1, artist = {'heroofyore'}},
    } ]] ---these are all for informational purposes

    
    SMODS.Atlas {
        key = "j_lucky_cat_anim",
        path = "UNFIVEABLE.png", 
        atlas_table = 'ANIMATION_ATLAS',
        frames = 3,
        px = 71, 
        py = 95,
    }

    SMODS.Atlas {
        key = "j_smeared_anim",
        path = "UNTENABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 9,
        px = 71,
        py = 95,
    }

    SMODS.Atlas {
        key = "j_baseball_anim",
        path = "UNWHACKABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 74,
        px = 71,
        py = 95,
    }

    SMODS.Atlas {
        key = "j_ramen_anim",
        path = "UNTENABLE.png",
        atlas_table  = 'ANIMATION_ATLAS',
        frames = 7,
        fps = 5,
        px = 71,
        py = 95,
    }

    SMODS.Atlas {
        key = "j_flower_pot_anim",
        path = "UNTENABLE.png",
        atlas_table  = 'ANIMATION_ATLAS',
        frames = 8,
        fps = 5,
        px = 71,
        py = 95,
    }

    SMODS.Atlas{
        key = "j_gift_anim",
        path = "UNFIVEABLE.png",
        atlas_table  = 'ANIMATION_ATLAS',
        frames = 5,
        px = 71,
        py = 95,
    }

    SMODS.Atlas{
        key = "j_egg_anim",
        path = "UNFIFTEENABLE.png",
        atlas_table  = 'ANIMATION_ATLAS',
        frames = 13,
        px = 71,
        py = 95,
    }

    SMODS.Atlas{
        key = "j_todo_list_anim",
        path = "UNJOURNALABLE.png",
        atlas_table  = 'ANIMATION_ATLAS',
        frames = 34,
        fps = 10,
        px = 71,
        py = 95,
    }
    SMODS.Atlas{
        key = "j_wee_anim",
        path = "UNCRUNCHABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 1,
        fps = 20,
        px = 71,
        py = 95,
    }

    SMODS.Atlas{
        key = "j_weeSPIN_anim",
        path = "UNCRUNCHSPINABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 30,
        fps = 20,
        px = 71,
        py = 95,
    }

        SMODS.Atlas{
        key = "j_odd_todd_anim",
        path = "UNFIVEABLE.png",
        atlas_table  = 'ANIMATION_ATLAS',
        frames = 4,
        fps = 3,
        px = 71,
        py = 95,
    }

        SMODS.Atlas{
        key = "j_burnt_anim",
        path = "UNFIFTEENABLE.png",
        atlas_table  = 'ANIMATION_ATLAS',
        frames = 12,
        fps = 5,
        px = 71,
        py = 95,
    }
        SMODS.Atlas{
        key = "j_superposition_anim",
        path = "UNFORTYABLE.png",
        atlas_table  = 'ANIMATION_ATLAS',
        frames = 40,
        fps = 14,
        px = 71,
        py = 95,
    }

        SMODS.Atlas{
        key = "j_bloodstone_anim",
        path = "UNTWENTYFIVEABLE.png",
        atlas_table  = 'ANIMATION_ATLAS',
        frames = 22,
        fps = 5,
        px = 71,
        py = 95,
    }
        SMODS.Atlas{
            key = "j_misprint_anim",
            path = "UNFIFTYABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 47,
            fps = 10,
            px = 71,
            py = 95
        }
        SMODS.Atlas{
            key = "j_constellation_anim",
            path = "UNTHIRTYABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 27,
            fps = 10,
            px = 71,
            py = 95
        }
        SMODS.Atlas{
            key = "j_invisible_anim",
            path = "UNFIFTEENABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 12,
            fps = 10,
            px = 71,
            py = 95
        }
        SMODS.Atlas{
            key = "j_madness_anim",
            path = "UNTENABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 10,
            fps = 10,
            px = 71,
            py = 95
        }
        SMODS.Atlas{
            key = "j_brainstorm_anim",
            path = "UNFIVEABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 4,
            fps = 10,
            px = 71,
            py = 95
        }
        SMODS.Atlas{
            key = "j_fibonacci_anim",
            path = "UNSIXTYFIVEABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 63,
            fps = 10,
            px = 71,
            py = 95
        }

        SMODS.Atlas{
            key = "j_jolly_anim",
            path = "UNTWENTYFIVEABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 23,
            fps = 10,
            px = 71,
            py = 95
        }
        SMODS.Atlas{
            key = "j_zany_anim",
            path = "UNTENABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 7,
            fps = 10,
            px = 71,
            py = 95
        }
        SMODS.Atlas{
            key = "j_astronomer_anim",
            path = "UNFORTYABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 36,
            fps = 30,
            px = 71,
            py = 95
        }
        SMODS.Atlas{
            key = "j_vampire_anim",
            path = "UNEIGHTYABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 77,
            fps = 10,
            px = 71,
            py = 95
        }
        SMODS.Atlas{
            key = "j_throwback_anim",
            path = "UNHUNDREDABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 104,
            fps = 10,
            px = 71,
            py = 95
        }
        SMODS.Atlas{
            key = "j_seance_anim",
            path = "UNHUNDREDABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 100,
            fps = 10,
            px = 71,
            py = 95
        }
            SMODS.Atlas{
            key = "j_campfire_anim",
            path = "UNFIVEABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 5,
            fps = 5,
            px = 71,
            py = 95
        }
            SMODS.Atlas {
            key = "j_shoot_the_moon_anim",
            path = "UNTHIRTYABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 28,
            fps = 10,
            px = 71,
            py = 95
        }
            SMODS.Atlas {
            key = "j_baron_anim",
            path = "UNFORTYABLE.png",
            atlas_table  = 'ANIMATION_ATLAS',
            frames = 34,
            fps = 5,
            px = 71,
            py = 95,
        }
        SMODS.Atlas {
        key = "j_dusk_anim",
        path = "UNFORTYABLE.png",
        atlas_table  = 'ANIMATION_ATLAS',
        frames = 40,
        fps = 5,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
        key = "j_supernova_anim",
        path = "UNNINETYABLE.png",
        atlas_table  = 'ANIMATION_ATLAS',
        frames = 89,
        fps = 10,
        px = 71,
        py = 95,
    }

    SMODS.Atlas {
        key = "j_hit_the_road_anim",
        path = "UNHITTABLE.png",
        atlas_table  = 'ANIMATION_ATLAS',
        frames = 6,
        fps = 10,
        px = 71,
        py = 95,
    }
    SMODS.Atlas {
        key = "j_stone_anim",
        path = "UNINTERROGATABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 20,
        fps = 5,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
        key = "j_reserved_parking_anim",
        path = "UNRESTABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 64,
        fps = 10,
        px = 71,
        py = 95,
    }
    SMODS.Atlas {
        key = "j_droll_anim",
        path = "UNPINKABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 13,
        fps = 10,
        px = 71,
        py = 95,
    }
    SMODS.Atlas {
        key = "j_onyx_agate_anim",
        path = "UNLIGHTABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 193,
        fps = 20,
        px = 71,
        py = 95,
    }
    SMODS.Atlas {
        key = "j_rocket_anim",
        path = "UNARRESTABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 8,
        fps = 10,
        px = 71,
        py = 95,
    }
    SMODS.Atlas {
        key = "j_splash_anim",
        path = "UNRAMENABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 38,
        fps = 10,
        px = 71,
        py = 95,
    }

    SMODS.Atlas {
        key = "j_drivers_license_anim",
        path = "UNTRILLABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 12,
        fps = 5,
        px = 71,
        py = 95,
    }

    SMODS.Atlas {
        key = "j_duo_anim",
        path = "UNTWINABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 32,
        fps = 10,
        px = 71,
        py = 95,
    }
    SMODS.Atlas {
        key = "j_trio_anim",
        path = "UNOMFABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 34,
        fps = 10,
        px = 71,
        py = 95,
    }
    SMODS.Atlas {
        key = "j_family_anim",
        path = "UNBANDABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 17,
        fps = 10,
        px = 71,
        py = 95,
    }
    SMODS.Atlas {
        key = "j_order_anim",
        path = "UNHARMABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 32,
        fps = 10,
        px = 71,
        py = 95,
    }
    SMODS.Atlas {
        key = "j_tribe_anim",
        path = "UNBEATABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 130,
        fps = 10,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
        key = "j_raised_fist_anim",
        path = "UNENDABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 130,
        fps = 20,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
        key = "j_mystic_summit_anim",
        path = "UNTONICABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 20,
        fps = 5,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
        key = "j_erosion_anim",
        path = "UNTREEABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 20,
        fps = 5,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
        key = "j_arrowhead_anim",
        path = "UNBELIEVABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 67,
        fps = 8,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
        key = "j_red_card_anim",
        path = "UNSKIPPABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 68,
        fps = 10,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
        key = "j_burglar_anim",
        path = "UNSTEALABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 124,
        fps = 10,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
        key = "j_wrathful_joker_anim",
        path = "UNBEARABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 89,
        fps = 10,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
        key = "j_card_sharp_anim",
        path = "UNDJABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 43,
        fps = 10,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
        key = "j_even_steven_anim",
        path = "UNSEWERABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 5,
        fps = 3,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
        key = "j_chaos_anim",
        path = "UNPRISONBALLABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 57,
        fps = 10,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
        key = "j_gluttenous_joker_anim",
        path = "UNCREAMABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 29,
        fps = 5,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
        key = "j_wily_anim",
        path = "UNLAVABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 47,
        fps = 10,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
        key = "j_mime_anim",
        path = "UNMIRRORABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 144,
        fps = 10,
        px = 71,
        py = 95,
    }
    SMODS.Atlas {
        key = "j_mad_anim",
        path = "UNHOLDABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 12,
        fps = 10,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
        key = "j_hack_anim",
        path = "UNDIRTABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 45,
        fps = 10,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
        key = "j_golden_anim",
        path = "UNBOYABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 40,
        fps = 10,
        px = 71,
        py = 95,
    }
        SMODS.Atlas {
            key = "j_runner_anim",
            path = "UNDODGEABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 39,
            fps = 10,
            px = 71,
            py = 95,
        }
        SMODS.Atlas{
            key = "j_scholar_anim",
            path = "UNTEACHABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 4,
            fps = 10,
            px = 71,
            py = 95,
        }        
        SMODS.Atlas{
            key = "j_idol_anim",
            path = "UNIDOLABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 46,
            fps = 10,
            px = 71,
            py = 95,
        }
        SMODS.Atlas{
            key = "j_crazy_anim",
            path = "UNSPAMABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 21,
            fps = 10,
            px = 71,
            py = 95,
        }
        SMODS.Atlas{
            key = "j_riff_raff_anim",
            path = "UNRIOTABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 10,
            fps = 10,
            px = 71,
            py = 95,
        }
        SMODS.Atlas{
            key = "j_fortune_teller_anim",
            path = "UNVHSABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 46,
            fps = 10,
            px = 71,
            py = 95,
        }
        SMODS.Atlas{
            key = "j_rough_gem_anim",
            path = "UNMIXABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 8,
            fps = 10,
            px = 71,
            py = 95,
        }
        SMODS.Atlas{
            key = "j_blue_joker_anim",
            path = "UNREFLECTABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 52,
            fps = 10,
            px = 71,
            py = 95,
        }
        SMODS.Atlas{
            key = "j_lusty_joker_anim",
            path = "UNDISTRACTABLE.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 139,
            fps = 10,
            px = 71,
            py = 95,
        }
        --divide for reduced animations. 
        SMODS.Atlas{
            key = "j_lusty_joker_reduced_anim",
            path = "UNDISTRACTABLE_REDUCED.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 99,
            fps = 10,
            px = 71,
            py = 95,
        }

        SMODS.Atlas {
            key = "j_mime_reduced_anim",
            path = "UNMIRRORABLE_REDUCED.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 110,
            fps = 10,
            px = 71,
            py = 95,
        }
            SMODS.Atlas {
            key = "j_tribe_reduced_anim",
            path = "UNBEATABLE_REDUCED.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 109,
            fps = 10,
            px = 71,
            py = 95,
        }
            SMODS.Atlas {
            key = "j_raised_fist_reduced_anim",
            path = "UNENDABLE_reduced.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 109,
            fps = 20,
            px = 71,
            py = 95,
        }
            SMODS.Atlas {
            key = "j_burglar_reduced_anim",
            path = "UNSTEALABLE_REDUCED.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 110,
            fps = 10,
            px = 71,
            py = 95,
        }
            SMODS.Atlas {
            key = "j_onyx_agate_reduced_anim",
            path = "UNLIGHTABLE_REDUCED.png",
            atlas_table = 'ANIMATION_ATLAS',
            frames = 107,
            fps = 10,
            px = 71,
            py = 95,
        }
        
    if not UNCARDABLE.config.disabled then
        for jkr, data in pairs(G.UNCARDABLE_animated_jokers) do
            SMODS["Joker"]:take_ownership(jkr, {atlas = jkr .. "_anim",
            pos = {x = 0, y = 0 + data.row},
            artist_credits = data.artist,
            --soul_pos = {x = 0, y = 1}
        }, true)
        end
        local joker_pool = {}
        for l, v in pairs(G.P_CENTER_POOLS.Joker) do
            if not v.original_mod then
                table.insert(joker_pool, v)
            end
        end
        for jkr, data in pairs(joker_pool) do
            print(data.key, " is currently being checked")
            if G.PROFILES[G.SETTINGS.profile].uncardable_alternates[data.key] ~= nil then
                local checkagainst = G.PROFILES[G.SETTINGS.profile].uncardable_alternates[data.key]
                print(checkagainst, " ", data.key)
                --local jokerdeclare, count = string.gsub(checkagainst, "_anim", "")
                local position
                local isAnimated = false
                if checkagainst == "agglomeration1" or checkagainst == "uncardable_agglomeration1" then
                    position = G.UNCARDABLE_jokers1[data.key]
                    print(position.pos)
                elseif checkagainst == "agglomeration2" or checkagainst == "uncardable_agglomeration2" then
                    position = G.UNCARDABLE_jokers2[data.key]
                
                elseif checkagainst == "agglomeration3" or checkagainst == "uncardable_agglomeration3"  then
                    position = G.UNCARDABLE_jokers3[data.key]
                else
                    position = G.UNCARDABLE_animated_jokers[data.key]
                    isAnimated = true
                    SMODS["Joker"]:take_ownership(data.key, {atlas = G.PROFILES[G.SETTINGS.profile].uncardable_alternates[data.key],
                    pos = {x = 0, y = 0 + position.row},
                    artist_credits = position.artist,
                }, true)
                end
                
                if isAnimated == false then
                    --print(position.pos)
                    SMODS["Joker"]:take_ownership(data.key, {atlas = G.PROFILES[G.SETTINGS.profile].uncardable_alternates[data.key],
                    pos = {x = 0 + position.pos, y = 0},
                    artist_credits = position.artist,
                    soul_pos = {x = 0 + position.pos, y = 1},
                    }, true)
                end
            else
                local possibleSkins = 0
                local skinType = {}
                local state = {}
                local atlastable = {}
                if G.UNCARDABLE_jokers1[data.key] ~= nil then
                    possibleSkins = possibleSkins + 1
                    skinType[#skinType+1] = G.UNCARDABLE_jokers1
                    state[#state+1] = "Static"
                    atlastable[#atlastable+1] = "agglomeration1"
	            end
	            if G.UNCARDABLE_jokers2[data.key] ~= nil then
                    possibleSkins = possibleSkins + 1
                    skinType[#skinType+1] = G.UNCARDABLE_jokers2
                    state[#state+1] = "Static"                    
                    atlastable[#atlastable+1] = "agglomeration2"
	            end
	            if G.UNCARDABLE_jokers3[data.key] ~= nil then
                    possibleSkins = possibleSkins + 1
                    state[#state+1] = "Static"
                    skinType[#skinType+1] = G.UNCARDABLE_jokers3
                    atlastable[#atlastable+1] = "agglomeration3"
	            end
            
	            if G.UNCARDABLE_animated_jokers[data.key] ~= nil then
                    possibleSkins = possibleSkins + 1
                    state[#state+1] = "Animated"
                    skinType[#skinType+1] = G.UNCARDABLE_animated_jokers
                    atlastable[#atlastable+1] = G.UNCARDABLE_animated_jokers[data.key].anim
	            end
                print("ps: ", possibleSkins, " ", skinType[chosen])
                if possibleSkins ~= 0 then
                    local chosen = math.random(1, possibleSkins)
                    if state[chosen] == "Static" then
                        SMODS["Joker"]:take_ownership(data.key, {
                            atlas = atlastable[chosen],
                            pos = {x = 0 + skinType[chosen][data.key].pos, 
                            y = 0},
                            artist_credits = skinType[chosen][data.key].artist,
                            soulpos = {x = 0 + skinType[chosen][data.key].pos, y = 1}
                        }, true)
                    else
                         SMODS["Joker"]:take_ownership(data.key, {
                            atlas = atlastable[chosen],
                            pos = {x = 0, y = 0 + skinType[chosen][data.key].row},
                            artist_credits = skinType[chosen][data.key].artist,
                        }, true)
                    end
                end
            end
        end
        if UNCARDABLE.config.reduced_anims then
            for jkr, data in pairs(G.UNCARDABLE_reduced_animation) do
                SMODS["Joker"]:take_ownership(jkr, {atlas = jkr .. "_reduced_anim",
                pos = {x = 0, y = 0},
                artist_credits = data.artist,
            }, true)
            end
        end
    end
    SMODS.Atlas{
        key = "j_perkeo_anim",
        path = "UNLEGENDABLE.png",
        atlas_table = 'ANIMATION_ATLAS',
        frames = 108,
        fps = 60,
        px = 71,
        py = 95
    }
    
    if not UNCARDABLE.config.disabled then
        for jkr, data in pairs(animated_with_soul) do
            SMODS["Joker"]:take_ownership(jkr, {atlas = jkr .. "_anim",
            pos = {x = 0, y = 0 + data.row},
            artist_credits = data.artist,
            soul_pos = {x = 0, y = 1 + data.row},
        }, true)
        end

                
        --[[SMODS.Joker:take_ownership('j_wee', {
            loc_vars = function(self, info_queue, card)
                return {vars = {card.ability.extra.chips, card.ability.extra.chip_mod}}
            end,
            calculate = function(self, card, context)
                if context.individual and context.cardarea == G.play and context.other_card:get_id() == 2 and not context.blueprint then
                    card.ability.extra.chips = card.ability.extra.chips + card.ability.extra.chip_mod
                    return 
                    {
                        message = localize('k_upgrade_ex'),
                        colour = G.C.CHIPS,
                        message_card = card
                    }
                end
                --print(G.CONTROLLER.hovering.target)
                local t = G.CONTROLLER.hovering.target
                if t.config.center_key == "j_wee" then
                    if card.children.center.atlas ~= G.ANIMATION_ATLAS["uncardable_j_weeSPIN_anim"] then
                        print("changing animation")
                        card.children.center.atlas = G.ANIMATION_ATLAS["uncardable_j_weeSPIN_anim"]
                    end

                else
                    print("no change")
                    card.children.center.atlas = G.ANIMATION_ATLAS["uncardable_j_wee_anim"]
                end
                if context.joker_main then
                    return {
                        chips = card.ability.extra.chips
                    }
                end


            end,
        }, true)]]
    end

    SMODS.Atlas {
        key = "SHOOTABLE",
        path = "UNSHOOTABLE.png",
        px = 71,
        py = 95
    }
    SMODS.Sound({
        key = 'BANG',
        path = 'BANG.ogg',
        replace = 'slice1'
    })
    SMODS.Sound({
        key = 'b_voice1',
        path = 'b_voice1.ogg',
        replace = 'voice1'
    })
    SMODS.Sound({
        key = 'b_voice2',
        path = 'b_voice2.ogg',
        replace = 'voice2'
    })
    SMODS.Sound({
        key = 'b_voice3',
        path = 'b_voice3.ogg',
        replace = 'voice3'
    })
    SMODS.Sound({
        key = 'b_voice4',
        path = 'b_voice4.ogg',
        replace = 'voice4'
    })    
    SMODS.Sound({
        key = 'b_voice5',
        path = 'b_voice5.ogg',
        replace = 'voice5'
    })
    SMODS.Sound({
        key = 'b_voice6',
        path = 'b_voice6.ogg',
        replace = 'voice6'
    })    
    SMODS.Sound({
        key = 'b_voice7',
        path = 'b_voice7.ogg',
        replace = 'voice7'
    })
    SMODS.Sound({
        key = 'b_voice8',
        path = 'b_voice8.ogg',
        replace = 'voice8'
    })    
    SMODS.Sound({
        key = 'b_voice9',
        path = 'b_voice9.ogg',
        replace = 'voice9'
    })
    SMODS.Sound({
        key = 'b_voice10',
        path = 'b_voice10.ogg',
        replace = 'voice10'
    })
    SMODS.Sound({
        key = 'b_voice11',
        path = 'b_voice11.ogg',
        replace = 'voice11'
    })
    if not UNCARDABLE.config.disabled then
        SMODS["Joker"]:take_ownership("j_ceremonial", {atlas = "SHOOTABLE",
        pos = {x = 0, y = 0},
        }, true)
    end

function UNCARDABLE.UNCARD_REINIT_SPRITES() 
	local joker_pool = {}
    print("reinitializing")
    for l, v in pairs(G.P_CENTERS) do
                local isj, count = string.gsub(l, "j_", "j_")
        if not v.original_mod and count == 1 then
            table.insert(joker_pool, v)
        end
    end
    for jkr, data in pairs(joker_pool) do
        print(data.key, " is currently being checked")
        if G.PROFILES[G.SETTINGS.profile].uncardable_alternates[data.key] ~= nil then
            local checkagainst = G.PROFILES[G.SETTINGS.profile].uncardable_alternates[data.key]
            print(checkagainst, " ", data.key)
            --local jokerdeclare, count = string.gsub(checkagainst, "_anim", "")
            local position
            local isAnimated = false
            if checkagainst == "agglomeration1" or checkagainst == "uncardable_agglomeration1" then
                position = G.UNCARDABLE_jokers1[data.key]
                print(position.pos)
            elseif checkagainst == "agglomeration2" or checkagainst == "uncardable_agglomeration2" then
                position = G.UNCARDABLE_jokers2[data.key]
            
            elseif checkagainst == "agglomeration3" or checkagainst == "uncardable_agglomeration3"  then
                position = G.UNCARDABLE_jokers3[data.key]
            else
                position = G.UNCARDABLE_animated_jokers[data.key]
                --G.P_CENTERS[data.key]:remove()
                print(position.row, "uncardable_"..G.PROFILES[G.SETTINGS.profile].uncardable_alternates[data.key])
                isAnimated = true
                --G.P_CENTERS[data.key] = SMODS.create_sprite(G.ROOM.T.x + 0.2 * G.ROOM.T.w, G.ROOM.T.y, G.CARD_W, G.CARD_H, G.ANIMATION_ATLAS["uncardable_"..G.PROFILES[G.SETTINGS.profile].uncardable_alternates[data.key]], {x = 0, y = 0 + position.row})
                SMODS["Joker"]:take_ownership(data.key, {atlas = "uncardable_"..G.PROFILES[G.SETTINGS.profile].uncardable_alternates[data.key],
                pos = {x = 0, y = 0 + position.row},
                unlocked = true,
                discovered = true,
                artist_credits = position.artist,
                }, true)
            end
            
            if isAnimated == false then
                --print(position.pos, "uncardable_"..G.PROFILES[G.SETTINGS.profile].uncardable_alternates[data.key], data.key)
                --G.P_CENTERS[data.key]:remove()
                --G.P_CENTERS[data.key] = SMODS.create_sprite(G.ROOM.T.x + 0.2 * G.ROOM.T.w, G.ROOM.T.y, G.CARD_W, G.CARD_H, G.ASSET_ATLAS["uncardable_"..G.PROFILES[G.SETTINGS.profile].uncardable_alternates[data.key]], { x = 0 + position.pos, y = 0})
                --G.P_CENTERS[data.key].unlocked = true
                --G.P_CENTERS[data.key].discovered = true
                SMODS["Joker"]:take_ownership(data.key, {atlas = "uncardable_"..G.PROFILES[G.SETTINGS.profile].uncardable_alternates[data.key],
                pos = {x = 0 + position.pos, y = 0},
                unlocked = true,
                discovered = true,
                artist_credits = position.artist,
                soul_pos = {x = 0 + position.pos, y = 1},
                }, true)
            end
        end
    end
end