G.UNCARDABLE_SPECTRALS = {
    c_familiar = {artist = {"heroofyore"}, anim = "c_familiar_anim"},
    c_grim = {artist = {'heroofyore'}, anim = "c_grim_anim"},
    c_incantation = {artist = {'heroofyore'}, anim = "c_incantation_anim"},
    c_talisman = {artist = {'heroofyore'}, anim = "c_talisman_anim"},
    c_aura = {artist = {'heroofyore'}, anim = "c_aura_anim"},
    c_wraith = {artist = {'heroofyore'}, anim = "c_wraith_anim"},
    c_sigil = {artist = {'heroofyore'}, anim = "c_sigil_anim"},
    c_ouija = {artist = {'heroofyore'}, anim = "c_ouija_anim"},
    c_ectoplasm = {artist = {'heroofyore'}, anim = "c_ectoplasm_anim"},
    c_immolate = {artist = {'heroofyore'}, anim = "c_immolate_anim"},
    c_ankh = {artist = {'heroofyore'}, anim = "c_ankh_anim"},
    c_deja_vu = {artist = {'heroofyore'}, anim = "c_deja_vu_anim"},
    c_trance = {artist = {'heroofyore'}, anim = "c_trance_anim"},
    c_medium = {artist = {'heroofyore'}, anim = "c_medium_anim"},
    c_cryptid = {artist = {'heroofyore'}, anim = "c_cryptid_anim"},
    c_black_hole = {artist = {'guac'}, anim = "c_black_hole_anim"},
    c_soul = {artist = {'guac'}, anim = "c_soul_anim"},
    c_hex = {artist = {'guac'}, anim = "c_hex_anim"},
}


SMODS.Atlas {
    key = "c_familiar_anim",
    path = "UNSPECTRABLE/UNFAMILIABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 16,
    fps = 5,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_grim_anim",
    path = "UNSPECTRABLE/UNGAZEABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 10,
    fps = 10,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_incantation_anim",
    path = "UNSPECTRABLE/UNINCANTABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 81,
    fps = 10,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_talisman_anim",
    path = "UNSPECTRABLE/UNPOSEABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 23,
    fps = 10,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_aura_anim",
    path = "UNSPECTRABLE/UNTETOABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 16,
    fps = 10,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_wraith_anim",
    path = "UNSPECTRABLE/UNSPIREABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 19,
    fps = 10,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_sigil_anim",
    path = "UNSPECTRABLE/UNSIGILABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 38,
    fps = 10,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_ouija_anim",
    path = "UNSPECTRABLE/UNPERFORMABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 53,
    fps = 10,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_ectoplasm_anim",
    path = "UNSPECTRABLE/UNVHSABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 69,
    fps = 10,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_immolate_anim",
    path = "UNSPECTRABLE/UNIMMOLATABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 12,
    fps = 10,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_ankh_anim",
    path = "UNSPECTRABLE/UNBOWABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 52,
    fps = 10,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_deja_vu_anim",
    path = "UNSPECTRABLE/UNJUXTABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 49,
    fps = 10,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_trance_anim",
    path = "UNSPECTRABLE/UNTAKEABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 28,
    fps = 10,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_medium_anim",
    path = "UNSPECTRABLE/UNDELETABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 80,
    fps = 10,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_cryptid_anim_1",
    path = "UNSPECTRABLE/UNSHOREABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 24,
    fps = 10,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_cryptid_anim_2",
    path = "UNSPECTRABLE/UNSHOREABLE_PLUSCREST.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 24,
    fps = 10,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_cryptid_anim_3",
    path = "UNSPECTRABLE/UNSHOREABLE_POCO.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 24,
    fps = 10,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_black_hole_anim",
    path = "UNSPECTRABLE/UNBLACKHOLEABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 21,
    fps = 10,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_soul_anim",
    path = "UNSPECTRABLE/UNSOULABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 108,
    fps = 30,
    px = 71,
    py = 95, 
}

SMODS.Atlas {
    key = "c_soul_soul",
    path = "UNSPECTRABLE/UNSOULSOUL.png",
    px = 71,
    py = 95,
}

SMODS.Atlas {
    key = "c_hex_anim",
    path = "UNSPECTRABLE/UNHEXABLE.png",
    atlas_table = "ANIMATION_ATLAS",
    frames = 104,
    fps = 20,
    px = 71,
    py = 95, 
    sprite_args = {
        frame_durations = {
            [1] = 2,
            [2] = 2,
            [3] = 2,
            [4] = 2,
            [5] = 2,
            [6] = 2,
            [7] = 2,
            [8] = 2,
            [9] = 2,
            [10] = 2,
            [11] = 2,
            [12] = 2,
            [13] = 2,
            [14] = 2,
            [15] = 2,
            [16] = 2,
            [17] = 2,
            [18] = 2,
            [19] = 2,
            [20] = 2,
            [21] = 2,
            [22] = 2,
            [23] = 2,
            [24] = 2,
            [25] = 2,
            [26] = 2,
            [31] = 2,
            [32] = 2,
            [33] = 2,
            [34] = 2,
            [40] = 2,
            [41] = 2,
            [42] = 2,
            [43] = 2,
            [44] = 2,
            [50] = 2,
            [52] = 2,
            [53] = 2,
            [54] = 2,
            [55] = 2,
            [56] = 2,
            [69] = 2,
            [70] = 2,
            [71] = 2,
            [72] = 2,
            [73] = 2,
            [74] = 2,
            [75] = 2,
            [76] = 2,
            [77] = 2,
            [78] = 2,
            [79] = 2,
            [80] = 2,
            [81] = 2,
            [82] = 2,
            [83] = 2,
            [84] = 2,
            [85] = 2,
            [86] = 2,
            [87] = 2,
            [88] = 2,
            [89] = 2,
            [90] = 2,
            [91] = 2,
            [92] = 2,
            [93] = 2,
            [94] = 2,
            [95] = 2,
            [96] = 2,
        }
    }
}

if not UNCARDABLE.config.disabled then
    for spectral, data in pairs(G.UNCARDABLE_SPECTRALS) do
        if spectral == "c_cryptid" then
            local randompos = math.random(1, 3)
            SMODS["Consumable"]:take_ownership(spectral, {
                atlas = spectral .. "_anim_" .. randompos,
                pos = {x = 0, y = 0},
                artist_credits = data.artist,
            }, true)
        elseif spectral == "c_soul" then
            SMODS["Consumable"]:take_ownership(spectral, {
                atlas = spectral .. "_anim",
                pos = {x = 0, y = 0},
                artist_credits = data.artist,
            }, true)
        else
            SMODS["Consumable"]:take_ownership(spectral, {
                atlas = spectral .. "_anim",
                pos = {x = 0, y = 0},
                artist_credits = data.artist,
            }, true)
        end
    end
end
            

