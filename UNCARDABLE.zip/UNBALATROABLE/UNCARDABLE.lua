

--if not UNBALATROABLE then
--    UNBALATROABLE = {}
--end
--local mod_path = "" .. SMODS.current_mod.path
--UNBALATROABLE.path = mod_path
--UNBALATROABLE_config = SMODS.current_mod.config
UNCARDABLE = SMODS.current_mod
maloaded = false

if next(SMODS.find_mod("malverk")) then
    maloaded = true
    print("MALVERK DETECTED")
    assert(SMODS.load_file('reskins/malcompat.lua'))()
end
--assert(SMODS.load_file("config.lua"))()
----UNBALATROABLE_config.gameset_toggle = true;
assert(SMODS.load_file('reskins/functions.lua'))()
if not maloaded then
    assert(SMODS.load_file('reskins/UNCARDABLE_JKR.lua'))()
end
assert(SMODS.load_file('reskins/UNCARDABLE_TAROT.lua'))()
assert(SMODS.load_file('reskins/UNCARDABLE_PLANETS.lua'))()
assert(SMODS.load_file('reskins/artistui.lua'))()
assert(SMODS.load_file('reskins/quipadds.lua'))()
assert(SMODS.load_file('reskins/UNCARDABLE_OTHER.lua'))()
assert(SMODS.load_file('reskins/UNCARDABLE_VOUCHER.lua'))()
assert(SMODS.load_file('reskins/UNCARDABLE_TAGS.lua'))()
assert(SMODS.load_file('reskins/palettes.lua'))()
assert(SMODS.load_file('reskins/UNCARDABLE_DECK.lua'))()
assert(SMODS.load_file('reskins/UNCARDABLE_BOOSTER.lua'))()
assert(SMODS.load_file('reskins/UNCARDABLE_SPECTRALS.lua'))()
assert(SMODS.load_file('reskins/UNCARDABLE_SEALS.lua'))()
assert(SMODS.load_file('reskins/UNCARDABLE_BLINDS.lua'))()
assert(SMODS.load_file('reskins/UNCARDABLE_STAKES.lua'))()
assert(SMODS.load_file('reskins/credits.lua'))()
-----------------------------
----------------------------



ranks = {"Jack", "Queen", "King"}
ranks_all = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"}

SMODS.Atlas {
    key = 'balatro_anim',
    path = 'UNCARDALOGO_ANIM.png',
    atlas_table = 'ANIMATION_ATLAS',
    frames = 32,
    px = 333,
    py = 216,
    sprite_args = {
        frame_durations = {
            [26] = 40,
        }
    }
    --prefix_config = {key = false}
}
SMODS.Atlas {
    key = 'balatro',
    path = 'uncardalogo.png',
    px = 333, 
    py = 216,
    prefix_config = {key = false}
}
--[[if not UNCARDABLE.config.disabled then
    local tempscale = 1.1*(G.debug_splash_size_toggle and 0.8 or 1)
    G.SPLASH_LOGO = SMODS.create_sprite(0, 0, 13*tempscale, 13*tempscale*216 / 333, G.ANIMATION_ATLAS["uncardable_balatro"], {x = 0, y = 0})
end]]
SMODS.Atlas {
    key = 'unbeataspades',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNBEATASPADESLC.png'
}

SMODS.Atlas {
    key = 'unbeataspades_hc',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNBEATASPADESHC.png'
}

SMODS.Atlas {
    key = 'unbeataspadesreverse',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNBEATASPADESLCREVERSE.png'
}

SMODS.Atlas {
    key = 'unbeataspades_hcreverse',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNBEATASPADESHCREVERSE.png'
}

SMODS.Atlas {
    key = 'unbeatahearts',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNBEATAHEARTSLC.png'
}
SMODS.Atlas {
    key = 'unbeatahearts_hc',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNBEATAHEARTSHC.png'
}

SMODS.Atlas {
    key = 'unbeataheartsreverse',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNBEATAHEARTSLCREVERSE.png'
}
SMODS.Atlas {
    key = 'DECKSKINS/unbeatahearts_hcreverse',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNBEATAHEARTSHCREVERSE.png'
}

SMODS.Atlas {
    key = 'unbeataclubs',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNBEATACLUBSLC.png'
}
SMODS.Atlas {
    key = 'unbeataclubs_hc',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNBEATACLUBSHC.png'
}

SMODS.Atlas {
    key = 'unbeataclubsreverse',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNBEATACLUBSLCREVERSE.png'
}
SMODS.Atlas {
    key = 'unbeataclubs_hcreverse',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNBEATACLUBSHCREVERSE.png'
}

SMODS.Atlas {
    key = 'unbeatadiamonds',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNBEATADIAMONDSLC.png'
}
SMODS.Atlas {
    key = 'unbeatadiamonds_hc',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNBEATADIAMONDSHC.png'
}

SMODS.Atlas {
    key = 'unbeatadiamondsreverse',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNBEATADIAMONDSLCREVERSE.png'
}
SMODS.Atlas {
    key = 'unbeatadiamonds_hcreverse',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNBEATADIAMONDSHCREVERSE.png'
}

SMODS.DeckSkin ({
    key = 'UnbeataSpades',
    suit = "Spades",
    ranks = ranks,
    lc_atlas = 'unbeataspades',
    hc_atlas = 'unbeataspades_hc',
    loc_txt = {
        ['en-us'] = 'UNBEATABLE'
    },
    pos_style = 'collab'
})

SMODS.DeckSkin({
    key = 'UnbeataHearts',
    suit = "Hearts",
    ranks = ranks,
    lc_atlas = 'unbeatahearts',
    hc_atlas = 'unbeatahearts_hc',
    loc_txt = {
        ['en-us'] = 'UNBEATABLE',
    },
    pos_style = 'collab'
})

SMODS.DeckSkin({
    key = 'UnbeataClubs',
    suit = "Clubs",
    ranks = ranks,
    lc_atlas = 'unbeataclubs',
    hc_atlas = 'unbeataclubs_hc',
    loc_txt = {
        ['en-us'] = 'UNBEATABLE',
    },
    pos_style = 'collab'
})

SMODS.DeckSkin({
    key = 'UnbeataDiamonds',
    suit = "Diamonds",
    ranks = ranks,
    lc_atlas = 'unbeatadiamonds',
    hc_atlas = 'unbeatadiamonds_hc',
    loc_txt = {
        ['en-us'] = 'UNBEATABLE',
    },
    pos_style = 'collab'
})

SMODS.DeckSkin ({
    key = 'UnbeataSpadesReverse',
    suit = "Spades",
    ranks = ranks,
    lc_atlas = 'unbeataspadesreverse',
    hc_atlas = 'unbeataspades_hcreverse',
    loc_txt = {
        ['en-us'] = 'UNBEATABLE REVERSE'
    },
    pos_style = 'collab'
})

SMODS.DeckSkin({
    key = 'UnbeataHeartsReverse',
    suit = "Hearts",
    ranks = ranks,
    lc_atlas = 'unbeataheartsreverse',
    hc_atlas = 'unbeatahearts_hcreverse',
    loc_txt = {
        ['en-us'] = 'UNBEATABLE REVERSE',
    },
    pos_style = 'collab'
})

SMODS.DeckSkin({
    key = 'UnbeataClubsReverse',
    suit = "Clubs",
    ranks = ranks,
    lc_atlas = 'unbeataclubsreverse',
    hc_atlas = 'unbeataclubs_hcreverse',
    loc_txt = {
        ['en-us'] = 'UNBEATABLE REVERSE',
    },
    pos_style = 'collab'
})

SMODS.DeckSkin({
    key = 'UnbeataDiamondsReverse',
    suit = "Diamonds",
    ranks = ranks,
    lc_atlas = 'unbeatadiamondsreverse',
    hc_atlas = 'unbeatadiamonds_hcreverse',
    loc_txt = {
        ['en-us'] = 'UNBEATABLE REVERSE',
    },
    pos_style = 'collab'
})

SMODS.Atlas{
    key = "tapesuit",
    px = 71,
    py = 95,
    path = "DECKSKINS/UNBEATATAPES.png"
}
SMODS.Atlas{
    key = "guitarsuit",
    px = 71,
    py = 95,
    path = "DECKSKINS/UNBEATAGUITARS.png"
}
SMODS.Atlas{
    key = "synthsuit",
    px = 71,
    py = 95,
    path = "DECKSKINS/UNBEATASYNTHS.png"
}
SMODS.Atlas {
    key = "drumsuit",
    px = 71,
    py = 95,
    path = "DECKSKINS/UNBEATADRUMS.png"
}


SMODS.DeckSkin({
    key = 'tapesuit_skin',
    suit = "Hearts",
    palettes = {
        {
            key = 'lc',
            ranks = ranks_all,
            display_ranks = ranks_all,
            atlas = "uncardable_tapesuit",
            pos_style = 'suit',
        }
    },
    loc_txt = {
        ["en-us"] = 'UNCARDABLE HEARTS'
    },
    has_ds_card_ui = function(card, self, palette)
        return true
    end,
    generate_ds_card_ui = function(card, deckskin, palette, info_queue, desc_nodes, specific_vars, full_UI_table)
        localize{ type = 'other', key = 'headsup', nodes = desc_nodes, vars = {}}
    end,
    pos_style = 'collab'
})
SMODS.DeckSkin({
    key = 'guitarsuit_skin',
    suit = "Spades",
    palettes = {
        {
            key = 'lc',
            ranks = ranks_all,
            display_ranks = ranks_all,
            atlas = "uncardable_guitarsuit",
            pos_style = 'suit',
        }
    },
    loc_txt = {
        ["en-us"] = 'UNCARDABLE SPADES'
    },
    has_ds_card_ui = function(card, self, palette)
        return true
    end,
    generate_ds_card_ui = function(card, deckskin, palette, info_queue, desc_nodes, specific_vars, full_UI_table)
        return localize{ type = 'other', key = 'uncardable_headsup', nodes = desc_nodes, vars = {}}
    end,
    pos_style = 'collab'
})
SMODS.DeckSkin({
    key = 'synthsuit_skin',
    suit = "Diamonds",
    palettes = {
        {
            key = 'lc',
            ranks = ranks_all,
            display_ranks = ranks_all,
            atlas = "uncardable_synthsuit",
            pos_style = 'suit',
        }
    },
    loc_txt = {
        ["en-us"] = 'UNCARDABLE DIAMONDS'
    },
    has_ds_card_ui = function(card, self, palette)
        return true
    end,
    pos_style = 'collab'
})
SMODS.DeckSkin({
    key = 'drumsuit_skin',
    suit = "Clubs",
    palettes = {
        {
            key = 'lc',
            ranks = ranks_all,
            display_ranks = ranks_all,
            atlas = "uncardable_drumsuit",
            pos_style = 'suit',
        }
    },
    loc_txt = {
        ["en-us"] = 'UNCARDABLE Clubs'
    },
    has_ds_card_ui = function(card, self, palette)
        return true
    end,
    pos_style = 'collab'
})

SMODS.Atlas {
    key = 'unniraspades',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNNIRASPADESLC.png'
}

SMODS.Atlas {
    key = 'unniraspades_hc',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNNIRASPADESHC.png'
}

SMODS.Atlas {
    key = 'unnirahearts',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNNIRAHEARTSLC.png'
}
SMODS.Atlas {
    key = 'unnirahearts_hc',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNNIRAHEARTSHC.png'
}

SMODS.Atlas {
    key = 'unniraclubs',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNNIRACLUBSLC.png'
}
SMODS.Atlas {
    key = 'unniraclubs_hc',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNNIRACLUBSHC.png'
}

SMODS.Atlas {
    key = 'unniradiamonds',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNNIRADIAMONDSLC.png'
}
SMODS.Atlas {
    key = 'unniradiamonds_hc',
    px = 71,
    py = 95,
    disable_mipmap = true;
    path = 'DECKSKINS/UNNIRADIAMONDSHC.png'
}

SMODS.DeckSkin ({
    key = 'UnniraSpades',
    suit = "Spades",
    ranks = ranks,
    lc_atlas = 'unniraspades',
    hc_atlas = 'unniraspades_hc',
    loc_txt = {
        ['en-us'] = 'UNNIRABLE'
    },
    pos_style = 'collab'
})

SMODS.DeckSkin({
    key = 'UnniraHearts',
    suit = "Hearts",
    ranks = ranks,
    lc_atlas = 'unnirahearts',
    hc_atlas = 'unnirahearts_hc',
    loc_txt = {
        ['en-us'] = 'UNNIRABLE',
    },
    pos_style = 'collab'
})

SMODS.DeckSkin({
    key = 'UnniraClubs',
    suit = "Clubs",
    ranks = ranks,
    lc_atlas = 'unniraclubs',
    hc_atlas = 'unniraclubs_hc',
    loc_txt = {
        ['en-us'] = 'UNNIRABLE',
    },
    pos_style = 'collab'
})

SMODS.DeckSkin({
    key = 'UnniraDiamonds',
    suit = "Diamonds",
    ranks = ranks,
    lc_atlas = 'unniradiamonds',
    hc_atlas = 'unniradiamonds_hc',
    loc_txt = {
        ['en-us'] = 'UNNIRABLE',
    },
    pos_style = 'collab'
})

SMODS.Atlas({
	key = "modicon",
	path = "icon.png",
	px = 27,
	py = 27
})

-----------------------------
-----------------------------

SMODS.Sound({
    vol = 1.0,
    pitch = 1,
    key = "music_uncardable",
    path = "music_uncardable_v4.ogg",
    select_music_track = function()
        return G.GAME
        and 1
    end,
    --[[sync = {
        music_uncardable_shop = true,
        music_uncardable_tarot = true,
        music_uncardable_planet = true,
        music_uncardable_shop = true,
    }]]
})

SMODS.Sound({
    vol = 1.0,
    pitch = 1,
    key = "music_uncardable_shop",
    path = "music_uncardable_shop.ogg",
    select_music_track = function()
        return G.GAME
        and (G.GAME and G.shop)
        and 50
    end,
    --[[sync = {
        music_uncardable = true,
        music_uncardable_tarot = true,
        music_uncardable_planet = true,
        music_uncardable_boss = true,
    }]]
})

SMODS.Sound({
    vol = 1.0,
    pitch = 1,
    key = "music_uncardable_tarot",
    path = "music_uncardable_tarot.ogg",
    select_music_track = function()
		return G.GAME
        and (G.booster_pack)
        and 100
    end,
    --[[sync = {
        music_uncardable = true,
        music_uncardable_boss = true,
        music_uncardable_planet = true,
        music_uncardable_shop = true,
    }]]
})

SMODS.Sound({
    vol = 1.0,
    pitch = 1,
    key = "music_uncardable_planet",
    path = "music_uncardable_planet.ogg",
    select_music_track = function()
		return G.GAME
        and (G.STATE and (G.STATE == G.STATES.SPECTRAL_PACK or G.booster_pack_meteors))
        and 200
    end,
    --[[sync = {
        music_uncardable = true,
        music_uncardable_tarot = true,
        music_uncardable_boss = true,
        music_uncardable_shop = true,
    }]]
})

SMODS.Sound({
    vol = 1.0,
    pitch = 1,
    key = "music_uncardable_boss",
    path = "music_uncardable_boss.ogg",
    select_music_track = function()
        return G.GAME
        and (G.GAME and G.GAME.blind and G.GAME.blind.boss)
        and 200
    end,
    --[[sync = {
        music_uncardable = true,
        music_uncardable_tarot = true,
        music_uncardable_planet = true,
        music_uncardable_shop = true,
    }]]
})

local UNCARDABLEConfigTab = function()
    unbal_nodes = {
        {
            n = G.UIT.R,
			config = { align = "cm" },
			nodes = {
				{
					n = G.UIT.O,
					config = {
						object = DynaText({
							string = "This toggle disables reskinned jokers.",
							colours = { G.C.WHITE },
							shadow = true,
							scale = 0.4,
						}),
					},
				},
			},
        }
    }
    left_settings = { n = G.UIT.C, config = { align = "tl", padding = 0.05 }, nodes = {} }
	right_settings = { n = G.UIT.C, config = { align = "tl", padding = 0.05 }, nodes = {} }
	config = { n = G.UIT.R, config = { align = "tm", padding = 0 }, nodes = { left_settings, right_settings } }
	unbal_nodes[#unbal_nodes + 1] = config
    unbal_nodes[#unbal_nodes + 1] = UIBox_button({
        colour = G.C.yore,
        button = "total_reskins",
        label = {localize("uncard_skins")},
        minw = 5.0,
        minh = 1.7,
        scale = 0.7, 
        id = "reskinned_jokers"
    })
    unbal_nodes[#unbal_nodes + 1] = UIBox_button({
        colour = HEX("F394FF"),
        button = "planet_reskins",
        label = {localize("uncard_planets")},
        minw = 5.0, 
        minh = 1.7,
        scale = 0.7,
        id = "reskinned_planets"
    })
    unbal_nodes[#unbal_nodes + 1] = create_toggle({
        label = "Disable Reskinned Jokers (requires restart to activate)",
        active_colour = HEX("E01BDE"),
        ref_table = UNCARDABLE.config,
        ref_value = "disabled",
    })
    --[[unbal_nodes[#unbal_nodes + 1] = create_toggle({
        label = "Enable chipispis mode. Probably requires restart",
        active_colour = HEX("E01BDE"),
        ref_table = UNCARDABLE.config,
        ref_value = "chipispis",
    })
    unbal_nodes[#unbal_nodes + 1] = create_toggle({
        label = "Enable random chipispis. Requires chipispis mode on.",
        active_colour = HEX("E01BDE"),
        ref_table = UNCARDABLE.config,
        ref_value ="chipnumsis",
    })]]
    unbal_nodes[#unbal_nodes + 1] = create_toggle({
        label = "Revert Tarot card borders from Reimagined to Original",
        active_colour = HEX("E01BDE"),
        ref_table = UNCARDABLE.config,
        ref_value = "tarotoriginal",
    })
    unbal_nodes[#unbal_nodes + 1] = create_toggle({
        label = "Reduce animations (prevents red/white issue)",
        active_colour = HEX("E01BDE"),
        ref_table = UNCARDABLE.config,
        ref_value = "reduced_anims",
    })
   --[[unbal_nodes[#unbal_nodes+1] = create_toggle({
        label = "Custom hand names",
        active_colour = HEX("E01BDE"),
        ref_table = UNCARDABLE.config,
        ref_value = "rename_hand_types",
    })]]
    return {
		n = G.UIT.ROOT,
		config = {
			emboss = 0.05,
			minh = 6,
			r = 0.1,
			minw = 10,
			align = "cm",
			padding = 0.2,
			colour = G.C.BLACK,
		},
		nodes = unbal_nodes,
	}
end

SMODS.current_mod.config_tab = UNCARDABLEConfigTab

G.FUNCS.close_initial_config = function()
    SMODS.save_mod_config(UNCARDABLE)
end




local game_main_menu_ref = Game.main_menu
function Game:main_menu(change_context)
    local ret = game_main_menu_ref(self, change_context)

    local newcard = Card(
			G.title_top.T.x,
			G.title_top.T.y,
			G.CARD_W,
			G.CARD_H,
			G.P_CARDS.empty,
			G.P_CENTERS.c_base,
			{ bypass_discovery_center = true }
		)
            G.title_top:emplace(newcard)
    newcard.no_ui = true
    newcard.states.visible = false
    G.SPLASH_BACK:define_draw_steps({
        {
            shader = "splash",
            send = {
                { name = "time", ref_table = G.TIMERS, ref_value = "REAL_SHADER"},
                { name = "vort_speed", val = 0.4 },
                { name = "colour_1", ref_table = G.C, ref_value = "splashpink"},
                {name = "colour_2", ref_table = G.C, ref_value = "splashblue"},
            },
        },
    })
    return ret
end